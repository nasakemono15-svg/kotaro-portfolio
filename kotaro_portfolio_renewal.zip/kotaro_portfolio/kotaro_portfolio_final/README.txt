# KOTARO NAKAMURA Portfolio — 提出版 初版

## 対応
- Windows: Chrome / Microsoft Edge
- スマートフォン: iPhone / Android のブラウザ
- レスポンシブ対応

## 今回入れた実素材
- ライブ写真：HOME
- 自分＋アーティストの写真：ABOUT
- ZINE Vol.1 / Vol.2：ZINE
- ライブ集合写真：CONNECTION

## note URL
WRITINGページに以下4本のnote記事をクリック可能なリンクとして追加しています。
1. https://note.com/samenai_15/n/n8011dbe2cf69
2. https://note.com/samenai_15/n/n73294aa977d7
3. https://note.com/samenai_15/n/n68c0eebc108e
4. https://note.com/samenai_15/n/n2f0804915008

## 写真について
提出前に、写真の撮影者・写っている方・バンド側などから、
大学提出用Webポートフォリオおよびプレゼンでの掲載許可を確認してください。

## Windowsでの確認
index.html をChromeまたはEdgeで開いてください。

## Web公開
最終提出でURLが必要な場合は、GitHub Pages等で公開すると、
WindowsでもスマホでもURLから閲覧できます。
